function askName() {
    let name = prompt("Привет, как тебя зовут?", "введи здесь имя");
    alert(`Приятного пользования, ${name}!`);
}

askName()